console.log("this is working");


$(document).ready(function(){

 /*Setting our cocktail score to zero to start out*/ 
  var cocktailScore = 0;

 /*First screen, the landing page is all that shows*/  
  $("section").hide();
  $("#landingPanel").show();

 /*When the user clicks on the tiki figure, you go to the first question page*/ 
  $("img").click(function(){
    $("#landingPanel").fadeOut("slow");
    $("#landingPanel").hide();
    $("#questionPage1").fadeIn("slow");
    $(".answercontainer").selectable();
    });

 /*User selects an answer
1. name my variable
2. get the value from the input
3. 
4.
 */
   $("form input:radio").click(function(){
      $("#questionPage1").fadeOut("slow");
      $("#questionPage1").hide();
      $("#questionPage2").fadeIn("slow");
   });
  




  });





// function question-one(){
//var 1 = 0; var 2 = 0;
//($id1).click(function{
 // var 1 = 5;
//})
// }

